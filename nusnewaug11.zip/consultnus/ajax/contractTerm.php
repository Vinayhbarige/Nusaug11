<?php
include '../dbconn.php';


$contract =   $_POST['contractId'];
$contract_query = "SELECT * FROM nus_supply_contract WHERE contract_id = '".$contract."'";
$contract_qry = mysqli_query($conn, $contract_query);
$contractDate = '';

while ($contract_row = mysqli_fetch_assoc($contract_qry)) {
	$contractDate = $contract_row['contractTermfromDate'].','.$contract_row['contractTermtoDate'];
}
echo $contractDate;
?>
 