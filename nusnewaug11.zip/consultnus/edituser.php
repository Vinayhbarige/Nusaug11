<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <title>Edit user Details</title> -->
    <link rel="stylesheet" href="css/edituser.css">
        <title>NUS Consulting Group |Edit user Details </title>
    <link rel="icon" href="img/social-square-n-blue.png">
    
</head>
<body>
<?php
include('dbconn.php');
$editsingledata = array();
$getsupplydetails = "SELECT * FROM nususerdata WHERE id=".$_GET['id']."";
$result = $conn->query($getsupplydetails);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $editsingledata[] = $row;
    }
}
?>
    <div class = "userform">
        <form action="postedituser.php" method="POST">
                <header class="head">
                <a class="edituserdetails">Edit user Details</a>
                <div class="close-btn"  onclick='window.history.go(-1);'>&times;</div>
                <br/>
            </header>
            <br>
        <hr width="450px" color="#E4EBF6" >
         <br>
            <label class ="usere" for ="username">User name</label>
            <br>
            <br>
            <input autocomplete="off" type="text" name="username" class="username" id="username" placeholder="Enter username" onkeyup="isEmpty()" value="<?=$editsingledata[0]['username']?>" required>
            <br>
            <br>
            <br>
            <label  class = "emaili" for ="email">Enter email</label>
            <br>
            <br>
            <input autocomplete="off" type="text" name="emailId" class="email" value="<?=$editsingledata[0]['emailId']?>" id="email" placeholder="Enter email" onkeyup="isEmpty()" required>
            <br>
            <br>
            <hr width="450px" color="#E4EBF6" >
            <br>
            
                <!-- <input class="btnSubmit" type="submit" value="Save changes" onclick="msg()"/>
                <input class="btn" type="submit" value="Cancel"/>
                <input class="resendinvite" type="submit" value="Resend invite" -->
                <div class="buttonSection">
                <!-- <input  name="resendinvite" value="Resend Invite" type="reset" class="resendinviteUser" > -->
                <input name="cancel" value="Cancel" type="reset" class="cancelUser" onclick=window.history.go(-1);>
                <input value="Save changes"  class="savechanges" id="enable_button" name ="submit" type="submit" >
            <br>
            </div>
        </form>
     
    </div>

  
        </body>
        </html>
        
 