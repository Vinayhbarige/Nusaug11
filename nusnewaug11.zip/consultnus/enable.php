<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <title>Edit user Details</title> -->
    <link rel="stylesheet" href="css/disable.css">
        <title>NUS Consulting Group |Edit user Details </title>
    <link rel="icon" href="img/social-square-n-blue.png">
    
</head>
<?php 
include('dbconn.php');
session_start();
$editsingledata = array();
$getsupplydetails = "SELECT * FROM nususerdata WHERE id=".$_GET['id']."";
$result = $conn->query($getsupplydetails);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $editsingledata[] = $row;
    }
}
?>
<body>
    <div class = "userform">
        <form action="postenableuser.php" method="POST">
                <header class="head">
                <a class="edituserdetails">Enable user</a>
                <div class="close-btn"  onclick='window.history.go(-1);'>&times;</div>
                <br/>
            </header>
            <br>
        <hr width="450px" color="#E4EBF6" >
         <br>
         
            <label  class = "disemaili" for ="email">Enter email</label>
            <br>
            <br>
            <input autocomplete="off" type="text" name="emailId" value="<?=$editsingledata[0]['emailId']?>" class="email" id="email" placeholder="Enter email" onkeyup="isEmpty()" required>
            <br>
            <br>
            <hr width="450px" color="#E4EBF6" >
            <br>
            
                <!-- <input class="btnSubmit" type="submit" value="Save changes" onclick="msg()"/>
                <input class="btn" type="submit" value="Cancel"/>
                <input class="resendinvite" type="submit" value="Resend invite" -->
                <div class="buttonSection">
                <!-- <input  name="resendinvite" value="Resend Invite" type="reset" class="resendinviteUser" > -->
                <input name="cancel" value="Cancel" type="reset" class="canceldisuser" onclick=window.history.go(-1);>
                <input value="Enable user"  class="disableuser" id="enable_button" name ="submit" type="submit" >
            <br>
            </div>
        </form>
     
    </div>

  
        </body>
        </html>
        
 