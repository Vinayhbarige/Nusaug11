<?php include 'dbconn.php'?>
<?php
session_start();
	 $sql = "INSERT INTO parentcompanydata (parentcompany) VALUES ('".$_POST['parentcompany']."')";
     $conn->query($sql);
     $_SESSION['createdparent'] = time();
     header('location:addcompany.php');
?>