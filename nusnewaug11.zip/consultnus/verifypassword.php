<?php

    include('dbconn.php');

    $username = $_POST['username'];
    $newpass = $_POST['newpassword'];
    $cnfpass = $_POST['cnfpassword'];


    $count1 = strlen($newpass);
    $count2 = strlen($cnfpass);

    if($count1 >= 8 && $count2 >= 8) {


    $result = strcmp($newpass,$cnfpass);

    $sql = "SELECT username FROM nususerdata WHERE binary username = '$username';";
    $query_result = mysqli_query($conn,$sql);

    $total_row = mysqli_num_rows($query_result);

    if($result == 0 && $total_row == 1) {
        // print_r($query_result);

        $hashpass = password_hash($newpass, PASSWORD_ARGON2I);
        $update_query = "UPDATE nususerdata SET password='$hashpass', accountstatus='Confirmed' WHERE username = '$username';";
        $query_result = mysqli_query($conn,$update_query);

        header("Location: signin.php");

    } else {
        header("Location: confirmlogin.php?error= Incorrect Username has been entered!!");
    }
} else {
    header('Location: confirmlogin.php?error= Password length should be more than 8 characters!!');
}



?>