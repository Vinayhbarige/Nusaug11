<?php
    include('security.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NUS FRS System</title>
    <link rel="icon" href="img/social-square-n-blue.png" />
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
    <div class="main">
        <div class="menu">

            <?php
                include('sidebar.php');

            ?>
        </div>
        <div class="mainContainer indexWrapper">
            
            <span class="bodyWelcome chColorOne">Welcome<strong> <?php echo $_SESSION['user']; ?>,</strong></span>
            <span class="bodyWelcome chColorTwo">to NUS Consulting Group's FRS (Flexible Reporting System)</span></span>
            <!-- <h1>NUS FRS System</h1> -->
            <span class="bodySent chColorTwo">portal which will allow you to access, view, and generate</span>
            <p class="chColorTwo">position reports relating to your energy supply contracts</p>
            <br>
            <span class="indexDisclaimer chColorTwo">To return to this Home screen at any time <br> simply click on the NUS Consulting Group logo.</span>
        </div>
    </div>
</body>
</html>