
<?php
include 'dbconn.php';

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/chosen/1.1.0/chosen.jquery.min.js"></script>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous"> -->
    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/entertrade.css">
    <!-- <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/functions.js"></script> -->
    <title>NUS Consulting Group | Entertrade</title>
    <link rel="icon" href="img/social-square-n-blue.png">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap');

.suplycnt{
    margin: 40px 0 0 300px;
}
/* Make circles that indicate the steps of the form: */
.step {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbbbbb;
  border: none;
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}
#nextBtn{
  float: right;
}
/*input[type=range]{
  background: #E3EBF6;
  border: none;
}*/
/* Mark the active step: */
.step.active {
  opacity: 1;
}

/* Mark the steps that are finished and valid: */
.step.finish {
  background-color: #04AA6D;
}
.cat{
  margin: 4px;
  
 /* overflow: hidden;*/
  float: left;
}

.cat label {
  float: left;
  line-height: 3.0em;
  /* width: 10.0em;  */
  height: 3.0em;
  font-size: 15px !important;
}

.cat label span {
  text-align: center;
  padding: 3px 0;
  display: block;
  background-color: #fff;
  border-radius:6px; 

}

.cat label input {
  position: absolute;
  display: none;
 
}
/* selects all of the text within the input element and changes the color of the text */
/*.cat label input + span{color: #fff;}
*/

/* This will declare how a selected input will look giving generic properties */
.cat input:checked + span {
    color: #ffffff;
    
}

.disabledbutton {
   color: grey;
   border:1px solid grey;
    opacity: 0.5;
}

.cat label span img{
  filter: grayscale(100%);
}
.activebutton{
  color: #1363F1!important;
  border:1px solid #1363F1;
  opacity: 1;
}


label {
  color: #345DA6;
  font-family: 'Roboto', sans-serif;
    font-style: normal;
    font-size: 15px;
  font-weight: 400;
  
    line-height: 152.4%;
    /*display: flex;*/
    margin-bottom: 6px;
    align-items: center;
    letter-spacing: -0.01em;
    padding: 0px!important;
    /*margin: 0 0 -15px 0;*/
}
.catw{
    display: inline-block;
}
.padmd0 h3{
  margin-top: 6px;
  font-size: 26px;
  color: #345DA6;

}
.padmd0 select{
  border:1px solid lightgrey;
  box-shadow: none;
  color: #000;
  height: 38px!important;
  background-color: rgb(255, 255, 255);
    cursor: pointer;
    color: #345DA6;
    border: 1px solid #1363F1;
    border-radius: 6px;
}
.padmd0 h6{
  text-transform: capitalize;
  color: #345DA6;
  font-size: 14px;
  /* letter-spacing: 1px; */
}
.switch {
  display: inline-block;
  height:27px;
  position: relative;
  width: 55px;
  top: 14px;
}

.switch input {
  display:none;
}

.switchs {
  display: inline-block;
  height: 27px;
  position: relative;
  width: 55px;
  top: 14px;
}

.switchs input {
  display:none;
}

.sliders {
  background-color: #ccc;
  bottom: 0;
  cursor: pointer;
  left: 0;
  position: absolute;
  right: 0;
  top: 0;
  transition: .4s;
}

.sliders:before {
  background-color: #fff;
  bottom: 4px;
  content: "";
  height: 20px;
  left: 4px;
  position: absolute;
  transition: .4s;
  width: 20px;
}

input:checked + .sliders {
  background-color: #1363F1;
}

input:checked + .sliders:before {
  transform: translateX(26px);
}

.sliders.rounds {
  border-radius: 34px;
}

.sliders.rounds:before {
  border-radius: 50%;
}

.slider {
  background-color: #ccc;
  bottom: 0;
  cursor: pointer;
  left: 0;
  position: absolute;
  right: 0;
  top: 0;
  transition: .4s;
}

.slider:before {
  background-color: #fff;
  bottom: 4px;
  content: "";
  height: 20px;
  left: 4px;
  position: absolute;
  transition: .4s;
  width: 20px;
}

input:checked + .slider {
  background-color: #1363F1;
}

input:checked + .slider:before {
  transform: translateX(26px);
}

.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
.contrac{
    background: white;
    border-radius: 8px;
}
.client{
    position: relative;
}
.searchs{
    position: absolute;
    top: 5px;
    left: 3px;
    width: 10%;
}
.page select{
    font-size: 10px;
    padding: 7px!important;
}
.flitr{
    position: absolute;
    right: 5px;
    top: 5px;
}
.fullwidth{
  width: 100%;
  float: unset!important;
}
.clientbr ul{
    padding-inline-start:0px;
}
.clientbr ul li{
    display: inline;
}
.clientbr ul li a{
    padding: 7px;
    text-decoration: none;
}
.client input[type="text"]{
    padding-left: 25px;
}
.units{
  display: none;
}
.indexcl{
  display: none;
}
.page{
    position: absolute;
    right: 15%;
    top: 5px;
}
.sttab{
  width: 77%;
}
.bfg{
  height: 1px;
  background-color: lightgrey;
}
div label input {margin-right: 100px;}
/*
This following statements selects each category individually that contains an input element that is a checkbox and is checked (or selected) and chabges the background color of the span element.
*/
/* .action input:hover +span{
  background-color: #fff;
  color: blue;
  border:1px solid blue;
  padding: 0px 10px;

} */
.action input:hover +span{
  background-color: #fff;
  opacity: 1;
  color: #1363F1;
  border: 1px solid #1363F1;
  padding: 0px 10px;
}
/* .action input:hover +span img{
  filter: invert(25%) sepia(94%) saturate(3383%) hue-rotate(215deg) brightness(98%) contrast(92%);
} */
.action input:checked + span{
  background-color: #fff;
  opacity: 1;
  color: #1363F1;
  border: 1px solid #1363F1;
  padding: 0px 10px;
}
/* .action input:checked + span img{
  filter: invert(25%) sepia(94%) saturate(3383%) hue-rotate(215deg) brightness(98%) contrast(92%);
} */

/*form {
    width: 400px;
    padding: 30px;
    border-radius: 15px;
    margin: 80px 0 0 0;
}*/
.chosen-container-single .chosen-single{
    height: 35px!important;
    padding: 6px 0px 0px 8px!important;
}
.tab {
        display: none;
      }
.widse{
    width:100%;
    margin: auto;
}
      .tab img {
        margin: 3px;
      }
      .padmd0{
   
    position: absolute;
    width: 46%;
    left: 58%;
    top: 5%;
    transform: translate(-50%, 0%);
}
body{
  background: #F9FBFD;
}
input[type=range] {
  -webkit-appearance: none;
  margin: 0px 0;
  width: 100%;
  border: none;
  background: #F9FBFD;
}
input[type=range]:focus {
  outline: none;
}
input[type=range]::-webkit-slider-runnable-track {
  width: 100%;
  height: 5px;
  cursor: pointer;
 
  background: #E3EBF6;
  border-radius: 1.3px;
  
}
input[type=range]::-webkit-slider-thumb {
  box-shadow: 1px 1px 1px rgba(0,0,0,0.5);
  border: 3px solid #fff;
  height: 17px;
  width: 17px;
  border-radius: 50%;
  background: #1363F1;
  
  cursor: pointer;
  -webkit-appearance: none;
  margin-top: -8px;
}
.allowdvi{
  padding-top: 24px;
}
input[type=range]:focus::-webkit-slider-runnable-track {
  background: #E3EBF6;
}
.diviy p{
  margin-bottom: 0px;
}
input[type=range]::-moz-range-track {
  width: 100%;
  height: 8.4px;
  cursor: pointer;
  box-shadow: 1px 1px 1px #000000, 0px 0px 1px #0d0d0d;
  background: #3071a9;
  border-radius: 1.3px;
  border: 0.2px solid #010101;
}
input[type=range]::-moz-range-thumb {
  box-shadow: 1px 1px 1px #000000, 0px 0px 1px #0d0d0d;
  border: 1px solid #000000;
  height: 36px;
  width: 16px;
  border-radius: 3px;
  background: #ffffff;
  cursor: pointer;
}
input[type=range]::-ms-track {
  width: 100%;
  height: 8.4px;
  cursor: pointer;
  background: transparent;
  border-color: transparent;
  border-width: 16px 0;
  color: transparent;
}
input[type=range]::-ms-fill-lower {
  background: #2a6495;
  border: 0.2px solid #010101;
  border-radius: 2.6px;
  box-shadow: 1px 1px 1px #000000, 0px 0px 1px #0d0d0d;
}
input[type=range]::-ms-fill-upper {
  background: #3071a9;
  border: 0.2px solid #010101;
  border-radius: 2.6px;
  box-shadow: 1px 1px 1px #000000, 0px 0px 1px #0d0d0d;
}
input[type=range]::-ms-thumb {
  box-shadow: 1px 1px 1px #000000, 0px 0px 1px #0d0d0d;
  border: 1px solid #000000;
  height: 36px;
  width: 16px;
  border-radius: 3px;
  background: #ffffff;
  cursor: pointer;
}
input[type=range]:focus::-ms-fill-lower {
  background: #E3EBF6;
}
input[type=range]:focus::-ms-fill-upper {
  background: #E3EBF6;
}

.form-control {
  background-color: rgb(255, 255, 255);
cursor: pointer;
color: #345DA6;
border: 1px solid #1363F1;
border-radius: 6px 0px 0px 6px;
}

.input-group-addon {
 
  background-color: rgb(255, 255, 255);
  cursor: pointer;
  color: #345DA6;
  border: 1px solid #1363F1;
/* border-radius: 6px; */
border-radius: 0 6px 6px 0;

}

#cancelBtn, #prevBtn {
  background-color: rgb(255, 255, 255);
cursor: pointer;
color: #345DA6;
border: 1px solid #1363F1;
border-radius: 6px;
}

.seasonyear {
    display:none;
    margin: 0 0 0 12px;
}
.calendarquater {
    display:none;
    margin: 0 0 0 12px;
}
.calendarmonths{
    display:none;
    margin: 0 0 0 12px;
}

#calenderseason {
    padding: 0 20px;
    
}

#monthyear {
    width: 650px;
    height: 33px;
}

#yearc {
    padding: 0 10px;
}

#quarteryear{
    padding: 0 10px;
}
#monthsyear {
    padding: 0 10px;
}
#checkc{
    margin: 0 0 0 7px;
}
/* #effectiveprices {
    position: absolute;
    bottom: 30%;
} */

#Q1 {
    padding: 0px 16px 0px;
    gap:10px;
}

#Q2{
    padding: 0px 16px 0px;
    gap:10px;
}
#Q3 {
    padding: 0px 16px 0px;
    gap:10px;
}
#Q4 {
    padding: 0px 16px 0px;
    gap:10px;
}

#aprsep {
    padding: 0px 16px 0px;
}

#octmar {
    padding: 0px 16px 0px;

}
#effectiveprices {
    margin: 4px 0 10px 120px;

}
#baseloadprices {
    margin: 4px  0 10px 0px;
}
.cur {
  position:absolute;
  z-index:1;
}
#tradevalue {
  width:74%;
}

.input-group-addon {
  position: absolute;
  top: 16.1%;
  padding: 10.5px 12px;
  font-size: 14px;
  font-weight: 400;
  line-height: 1;
  /* color: #555; */
   text-align: center;
  border-radius: 0 6px 6px 0;
  /* background-color: #eee; */
  /* border: 1px solid #ccc; */
  /* border-radius: 4px; */

      /* background-color: rgb(255, 255, 255) !important;
  cursor: pointer !important;
  color: #345DA6 !important;
  border: 1px solid #1363F1 !important; */
}
.input-group {
  position: relative;
  /* display: table; */
  border-collapse: separate;
}

.tradevolume {
  margin:0 0 0 15px;
}
    </style>
</head>
<body>

    <div class="containertrade">
        <form action="">
            <div class="header">
                <h2 class="entry">Trade entry</h2>
                <h1 class="trade">New trade entry</h1>
            </div>
    
            <div class="contents">
                <div class="clientDetails">
                    <label class="clientData">Client</label>
                        <select  id="client" name="clientcompany">
                            <option selected disabled>Select Client</option>
                                <?php 

                              $country = "SELECT * FROM clientcompanydata";
                              $county_qry = mysqli_query($conn, $country);
                                while ($row = mysqli_fetch_assoc($county_qry)) : ?>
                                    <option value="<?php echo $row['id']; ?>"> <?php echo $row['clientcompany']; ?> </option>
                                <?php endwhile; ?>
                    </select>
                    
                </div>
<br>
            <div class="contractDetails">
                <label class="contractData">Contract</label>
                    <select id="contract" name='clientId' onchange="contractTerm(this.value)">
                        <option selected disabled>Select Contract</option>
                    </select>
                    <!-- <option id= "nusclient" class="clients" onchange="showdiv('parent', this)">NUS Client  </option> -->
            </div>
            <input type="hidden" class="contractTerm">
            <div class="headers">
                <div>
                    <span class="tradePeriod">Trade period</span>
                    <span class="year">Year</span>
                </div>
            </div>
<br>
            <div id = "checkc" style="display: inline-block;">
                        <div class="cat action">
                         <label>
                            <input type="checkbox" value="CalendarYear" name="Tradeperiod[]" class="Tradeperiod" 
                            checked><span id = "yearc" class="disabledbutton act">Calendar Year</span>
                         </label>
                      </div>
                      <div class="cat action">
                         <label>
                            <input type="checkbox" value="CalendarQuarters"  name="Tradeperiod[]" class="Tradeperiod"
                            
                            ><span id = "quarteryear" class="disabledbutton dis">Calendar Quarters</span>
                         </label> 
                      </div>
                      <div class="cat action">
                         <label>
                            <input type="checkbox" value="CalendarMonth"  name="Tradeperiod[]" class="Tradeperiod"
                            ><span id = "monthsyear" class="disabledbutton dis">Calendar Month</span>
                         </label> 
                      </div>
                      <div class="cat action">
                         <label>
                            <input type="checkbox" value="Season"  name="Tradeperiod[]" class="Tradeperiod"
                            
                            ><span id = "calenderseason" class="disabledbutton dis">Season</span>
                         </label> 
                      </div>
                      
                     
                      <div class="cat action">
                        <select id="ddlYears">
                            <option selected disabled>Select the year</option>
                        </select>
                    </div>
                    </div>
                    <div class="dynamiccheckbox">
                        <div class="seasonyear">

                       <label for="">Season</label>
                        <div style="display: inline-block;">
                            <div class="cat action">
                                <label>
                                    <input type="checkbox" value="oct-mar" name="seasonname[]" class="seasonname" 
                                    checked><span id ="octmar" class="disabledbutton act">Oct-Mar</span>
                                </label>
                            </div>

                            <div class="cat action">
                                <label>
                                    <input type="checkbox" value="apr-sep"  name="seasonname[]" class="seasonname"
                                    
                                   ><span id = "aprsep" class="disabledbutton dis">Apr-Sep</span>
                                </label> 
                            </div>
                        </div>
                    </div>

                    <div class="calendarquater">

                        <label for="">Quarter</label>
                        <div style="display: inline-block;">
                            <div class="cat action">
                                <label>
                                    <input type="checkbox" value="q1" name="Quarter[]" class="Quarter" 
                                    checked><span id = "Q1" class="disabledbutton act">Q1</span>
                                </label>
                            </div>

                            <div class="cat action">
                                <label>
                                    <input type="checkbox" value="q2"  name="Quarter[]" class="Quarter"
                                    
                                   ><span id = "Q2" class="disabledbutton dis">Q2</span>
                                </label> 
                            </div>

                            <div class="cat action">
                                <label>
                                    <input type="checkbox" value="q3" name="Quarter[]" class="Quarter" 
                                  ><span id = "Q3"class="disabledbutton act">Q3</span>
                                </label>
                            </div>

                            <div class="cat action">
                                <label>
                                    <input type="checkbox" value="q4"  name="Quarter[]" class="Quarter"
                                    
                                     ><span  id = "Q4"class="disabledbutton dis">Q4</span>
                                </label> 
                            </div>
                        </div>
                        </div>

                        <div class="calendarmonths">

                            <label for="">Calandar Month</label>
                            <div style="display: inline-block;">
                            <select id="monthyear" class="form-control" name= "month">
                            <?php 
                                $month = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];                            
                                
                                for ($i=0;$i<count($month);$i++) {
                                    
                                    ?> 
                                   
                                   <option value="<?=$month[$i]?>"><?=$month[$i]?></option>
                               
                                <?php }
                            ?>
                                 </select>
                            </div>
                        </div>
<br>
<!-- <br> -->
                        <!-- <div class="baseload">
                            <label for="baseLoad" class= "loadprice">Base load price</label>
                            <br>
                            <input type="text" placeholder="0.00">

                            <label for="effectiveprice" class="effectiveprice">Effective price</label>
                            <br>
                            <input type="text" placeholder="0.00"> 
                        </div> -->

                        <!-- <div>
                          <label for="tradevolume">Trade Volume</label>
                                               
                          <input type="text" name="" id="tradevalue" placeholder="Enter Fixed Consumption"><img class="cur" src="img/form-addon.svg">

                        </div> -->
                       <div class="tradevolume">
                          <label>Trade Volume</label>
                          <div class="input-group">
                              <input class="form-control left-border-none totalanualconsumption" id="tradevalue" placeholder="Enter trade Consumption" onkeypress="return CheckNumeric()" onkeyup="FormatCurrency(this)" type="text" value="" name="totalanualconsumption" >
                              <span class="input-group-addon transparent">
                              MWh</span>
                        </div>
                      </div>

                        <div id = "baseloadprices" class="cat action">
                            <label for="baseLoad" class= "loadprice">Base load price</label>
                            <br>
                            <input class ="loadprice" type="text" placeholder="0.00">
                            
                      </div>
                        
                        <div id ="effectiveprices" class="cat action">
                            <label for="effectiveprice" class="effectiveprice">Effective price</label>
                            <br>
                            <input class ="effectiveprice" type="text" placeholder="0.00"> 
                      </div>
                      
                      
                     
                        <!-- <div class="effectiveprice">
                            <label for="effectiveprice" class="effectiveprice">Effective price</label>
                            <br>
                            <input type="text" placeholder="0.00"> 
                        </div> -->
                    <br>
                    <br>
                            <button class="enterTradebtn">Enter trade</button>
                        </div>
                    </div>
                </div>
        </form>
    </div>
</body>

<script>
    // County State
    $('.Tradeperiod').each(function() {
        $(this).on('change',function() {
            if($(this).prop('checked',true)) {
                if($(this).val()=='Season') {
                    $('.seasonyear').css('display','block');
                }
                else{
                    $('.seasonyear').css('display','none');
                }
                if($(this).val()=='CalendarQuarters') {
                  
                    $('.calendarquater').css('display','block');
                }
                else{
                    $('.calendarquater').css('display','none');
                }
                if($(this).val()=='CalendarMonth') {
                    $('.calendarmonths').css('display','block');
                }
                else{
                    $('.calendarmonths').css('display','none');
                }
            }
            
        })
    })

    $('#client').on('change', function() {
        var clientId = this.value;
        console.log(clientId);
        $.ajax({
            url: 'ajax/contract.php',
            type: "POST",
            data: {
                country_data: clientId
            },
            success: function(result) {
                $('#contract').html(result);
                // console.log(result);
            }
        })
    });
    function contractTerm(contract){
        $.ajax({
            url: 'ajax/contractTerm.php',
            type: "POST",
            data: {
                contractId: contract
            },
            success: function(result) {
              var dates = result.split(",");
              var fromdate = new Date(dates[0]);
              var todate = new Date(dates[1]);
              first = fromdate.getFullYear();
              second = todate.getFullYear();
              arr = Array();
              for(i = first; i <= second; i++) arr.push(i);
              var months=0;
              months = (todate.getFullYear() - fromdate.getFullYear()) * 12;
              months -= fromdate.getMonth();
              months += todate.getMonth();
           
              var monthsdata = months+1;
              var printdata = '';
                printdata +='<option >Select the Year</option>';
              for(i=0;i<arr.length;i++){
               
                printdata +='<option value="'+arr[i]+'">'+arr[i]+'</option>';
              }
              $('#ddlYears').html(printdata);
              console.log(monthsdata);
              $('.Tradeperiod').each(function() {
                if(monthsdata>12){
                  if($(this).val() == 'CalendarYear'){

                    $(this).prop('checked',true).trigger("change");
                  }
                }
                if(monthsdata>=6 && monthsdata<12){
                  if($(this).val() == 'Season'){
                    $(this).prop('checked',true).trigger("change");
                  }
                }
                if(monthsdata==4 || monthsdata==5 ){
                  if($(this).val() == 'CalendarQuarters'){
                    $(this).prop('checked',true).trigger("change");
                  }
                }
                if(monthsdata<4){
                  if($(this).val() == 'CalendarMonth'){
                    $(this).prop('checked',true).trigger("change");
                  }
                }

                
                
              })
            }
        })
    }
    $('input[type="checkbox"].Tradeperiod').on('change', function() {
   $('input[type="checkbox"].Tradeperiod').not(this).prop('checked', false);
   

});

$('input[type="checkbox"].seasonname').on('change', function() {
    $('input[type="checkbox"].seasonname').not(this).prop('checked',false);
    
});

$('input[type="checkbox"].Quarter').on('change', function() {
    $('input[type="checkbox"].Quarter').not(this).prop('checked',false);
    
});
</script>


<script type="text/javascript">
    window.onload = function () {
        //Reference the DropDownList.
        var ddlYears = document.getElementById("ddlYears");
 
        //Determine the Current Year.
        var currentYear = (new Date()).getFullYear();
        currentYear += 30;
 
        //Loop and add the Year values to DropDownList.
        for (var i = 1950; i <= currentYear; i++) {
            var option = document.createElement("OPTION");
            option.innerHTML = i;
            option.value = i;
            ddlYears.appendChild(option);
        }
    };
</script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

</html>