<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NUS Consulting Group | Move users </title>
    <link rel="icon" href="img/social-square-n-blue.png">
    <link rel="stylesheet" href="css/move.css">
    <title>NUS Consulting Group |Move user</title>
    <link rel="icon" href="img/social-square-n-blue.png">
    
</head>
<body>
<?php 
include('dbconn.php');
session_start();
$editsingledata = array();
$getsupplydetails = "SELECT * FROM nususerdata WHERE id=".$_GET['id']."";
$result = $conn->query($getsupplydetails);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $editsingledata[] = $row;
    }
}
?>
    <div class = "userform">
        <form action="postmoveuser.php" method="post">
            <header class="head">
                <a class="moveuser">Move user</a>
                <div class="close-btns"  onclick='window.history.go(-1);'>&times;</div>
                <br/>
            </header>
            <br>
        <hr width="450px" color="#E4EBF6" >
            <br>
            <label  class = "emailid" for ="email">Enter email</label>
            <br>
            <br>
            <input autocomplete="off" type="text" name="emailId" value="<?=$editsingledata[0]['emailId']?>" class="email" id="email" placeholder="Enter email" onkeyup="isEmpty()" required>
            <br>
            <br>
            <label class ="role" for="">Role</label>
            <br>
            <br>
                <select name="role">
                   
                    <option value="Admin"
                    <?php
                    if($editsingledata[0]['role'] == 'Admin'){
                        echo 'selected';
                    }
                    ?>>Admin</option>
                    <option  value="NUS Manager"
                    <?php
                    if($editsingledata[0]['role'] == 'NUS Manager'){
                        echo 'selected';
                    }
                    ?>
                    >NUS Manager</option>
                    <option value="NUS User" 
                    <?php
                    if($editsingledata[0]['role'] == 'NUS User'){
                        echo 'selected';
                    }
                    ?>
                    >NUS User</option>
                    <option value="Parent company" 
                    <?php
                    if($editsingledata[0]['role'] == 'Parent company'){
                        echo 'selected';
                    }
                    ?>
                    >Parent company</option>
                    <option value="Client company" 
                    <?php
                    if($editsingledata[0]['role'] == 'Client company'){
                        echo 'selected';
                    }
                    ?>
                    >Client company</option>
                </select>
                <br>
                <br>
                <hr width="450px" color="#E4EBF6" >
                <br>
                <input class="btnSubmit" type="submit" name="submit" value="Save changes" onclick="msg()">
                <input class="btn" type="submit" value="Cancel" onclick=window.history.go(-1);>
            <br>
            </form>
            
        </div>

        </body>
        </html>
        
 